# IStruzioni Compilazione Progetto

Se non presente, scarica Nodejs (LTS) da questo link `https://nodejs.org/it/`

Apri la cartella del progetto (quella in cui è presente questo file)

Tenendo premuto `SHIFT`, premi il tasto destro del mouse su uno spazio vuoto della finestra (NON SU I FILES!)

Premi `Apri Finestra PowerShell qui` | `Open PowewShell Window here`

Digita `npm i`

Una volta terminato il processo digita `ng serve`

Apri un qualsiasi browser e inserisci nella barra degli indirizzi il seguente link `http://localhost:4200`



