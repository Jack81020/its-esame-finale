import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-main',
  templateUrl: './main.component.html',
  styleUrls: ['./main.component.scss']
})
export class MainComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

  list = [
    {
      attraction: "Colosseo",
      location: "Roma",
      interests: [1, 2],
      currentVisitors: 80,
      isOpen: true,
      avaiability: [
        {
          openingDayMonth: [5, 5],
          openingDayweekHourMinute: [0, 10, 0]
        },{
          closingDayMonth: [15, 10],
          closingDayweekHourMinute: [4, 18, 30]
        }
      ],
      closeCode: 1,
      avgRest: 55,
      personAnalytics: [
        {
          ingoing: [6,6,6,5],
          outgoing: [6,6,6,5],
          now: [6,6,6,5]
        }
      ],
      avgTime: [
        {hour: 0, people: 55},
        {hour: 1, people: 55},
        {hour: 2, people: 55},
        {hour: 3, people: 55},
        {hour: 4, people: 55},
        {hour: 5, people: 55},
        {hour: 6, people: 55},
        {hour: 7, people: 55},
        {hour: 8, people: 55},
        {hour: 9, people: 55},
        {hour: 10, people: 55},
        {hour: 11, people: 55},
        {hour: 12, people: 55},
        {hour: 13, people: 55},
        {hour: 14, people: 55},
        {hour: 15, people: 55},
        {hour: 16, people: 55},
        {hour: 17, people: 55},
        {hour: 18, people: 55},
        {hour: 19, people: 55},
        {hour: 20, people: 55},
        {hour: 21, people: 55},
        {hour: 22, people: 55},
        {hour: 23, people: 55}
      ]
    },
    {
      attraction: "Piazza San Marco",
      location: "Venezia",
      interests: [1, 2],currentVisitors: 80,
      isOpen: true,
      avaiability: [
        {
          openingDayMonth: [5, 5],
          openingDayweekHourMinute: [0, 10, 0]
        },{
          closingDayMonth: [15, 10],
          closingDayweekHourMinute: [4, 18, 30]
        }
      ],
      closeCode: 1,
      avgRest: 55,
      personAnalytics: [
        {
          ingoing: [6,6,6,5],
          outgoing: [6,6,6,5],
          now: [6,6,6,5]
        }
      ],
      avgTime: [
        {hour: 0, people: 55},
        {hour: 1, people: 55},
        {hour: 2, people: 55},
        {hour: 3, people: 55},
        {hour: 4, people: 55},
        {hour: 5, people: 55},
        {hour: 6, people: 55},
        {hour: 7, people: 55},
        {hour: 8, people: 55},
        {hour: 9, people: 55},
        {hour: 10, people: 55},
        {hour: 11, people: 55},
        {hour: 12, people: 55},
        {hour: 13, people: 55},
        {hour: 14, people: 55},
        {hour: 15, people: 55},
        {hour: 16, people: 55},
        {hour: 17, people: 55},
        {hour: 18, people: 55},
        {hour: 19, people: 55},
        {hour: 20, people: 55},
        {hour: 21, people: 55},
        {hour: 22, people: 55},
        {hour: 23, people: 55}
      ]
    },
    {
      attraction: "Galleria degli Uffizi",
      location: "Firenze",
      interests: [3, 1],currentVisitors: 80,
      isOpen: true,
      avaiability: [
        {
          openingDayMonth: [5, 5],
          openingDayweekHourMinute: [0, 10, 0]
        },{
          closingDayMonth: [15, 10],
          closingDayweekHourMinute: [4, 18, 30]
        }
      ],
      closeCode: 1,
      avgRest: 55,
      personAnalytics: [
        {
          ingoing: [6,6,6,5],
          outgoing: [6,6,6,5],
          now: [6,6,6,5]
        }
      ],
      avgTime: [
        {hour: 0, people: 55},
        {hour: 1, people: 55},
        {hour: 2, people: 55},
        {hour: 3, people: 55},
        {hour: 4, people: 55},
        {hour: 5, people: 55},
        {hour: 6, people: 55},
        {hour: 7, people: 55},
        {hour: 8, people: 55},
        {hour: 9, people: 55},
        {hour: 10, people: 55},
        {hour: 11, people: 55},
        {hour: 12, people: 55},
        {hour: 13, people: 55},
        {hour: 14, people: 55},
        {hour: 15, people: 55},
        {hour: 16, people: 55},
        {hour: 17, people: 55},
        {hour: 18, people: 55},
        {hour: 19, people: 55},
        {hour: 20, people: 55},
        {hour: 21, people: 55},
        {hour: 22, people: 55},
        {hour: 23, people: 55}
      ]
    },
    {
      attraction: "Cinque Terre",
      location: "Varie",
      interests: [2],
      currentVisitors: 80,
      isOpen: true,
      avaiability: [
        {
          openingDayMonth: [5, 5],
          openingDayweekHourMinute: [0, 10, 0]
        },{
          closingDayMonth: [15, 10],
          closingDayweekHourMinute: [4, 18, 30]
        }
      ],
      closeCode: 1,
      avgRest: 55
    },
    {
      attraction: "Costa Amalfitana",
      location: "Varie",
      interests: [2],currentVisitors: 80,
      isOpen: true,
      avaiability: [
        {
          openingDayMonth: [5, 5],
          openingDayweekHourMinute: [0, 10, 0]
        },{
          closingDayMonth: [15, 10],
          closingDayweekHourMinute: [4, 18, 30]
        }
      ],
      closeCode: 1,
      avgRest: 55,
      personAnalytics: [
        {
          ingoing: [6,6,6,5],
          outgoing: [6,6,6,5],
          now: [6,6,6,5]
        }
      ],
      avgTime: [
        {hour: 0, people: 55},
        {hour: 1, people: 55},
        {hour: 2, people: 55},
        {hour: 3, people: 55},
        {hour: 4, people: 55},
        {hour: 5, people: 55},
        {hour: 6, people: 55},
        {hour: 7, people: 55},
        {hour: 8, people: 55},
        {hour: 9, people: 55},
        {hour: 10, people: 55},
        {hour: 11, people: 55},
        {hour: 12, people: 55},
        {hour: 13, people: 55},
        {hour: 14, people: 55},
        {hour: 15, people: 55},
        {hour: 16, people: 55},
        {hour: 17, people: 55},
        {hour: 18, people: 55},
        {hour: 19, people: 55},
        {hour: 20, people: 55},
        {hour: 21, people: 55},
        {hour: 22, people: 55},
        {hour: 23, people: 55}
      ]
    }
  ]
}
