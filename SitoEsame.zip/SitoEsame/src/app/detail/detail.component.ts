import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-detail',
  templateUrl: './detail.component.html',
  styleUrls: ['./detail.component.scss']
})
export class DetailComponent implements OnInit {

  constructor(private router:Router) { }
  data: any;
  ngOnInit(): void {
    /* this.name = history.state.name
    this.location = history.state.location
    this.theme = history.state.theme
    this.attraction = history.state.attraction */
    console.log(history.state.data)
    this.data = history.state.data
  }

  orderpage(number){
    this.router.navigateByUrl("order", { state: { data: this.data, number: number }});
  }
}
