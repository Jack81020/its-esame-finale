import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-order',
  templateUrl: './order.component.html',
  styleUrls: ['./order.component.scss']
})
export class OrderComponent implements OnInit {
  orderId: number;
  data: any;
  constructor(private router: Router) { }

  ngOnInit(): void {
    console.log(history.state);
    this.data = history.state.data;
    this.orderId = history.state.number;
  }

  buy(id, location) {
    window.alert("Acquistato")
  }
}
